import { NextResponse } from 'next/server';
import { analyzeConversation } from '@/lib/openai';

export async function POST(request: Request) {
  try {
    const { text } = await request.json();
    const analysis = await analyzeConversation(text);
    
    return NextResponse.json(analysis);
  } catch (error) {
    console.error('Error analyzing conversation:', error);
    return NextResponse.json(
      { error: 'Failed to analyze conversation' },
      { status: 500 }
    );
  }
}